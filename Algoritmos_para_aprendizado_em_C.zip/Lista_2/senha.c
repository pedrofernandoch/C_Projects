#include <stdio.h>
#include <stdlib.h>

int main()
{
   int x;

    scanf("%d",&x);
    
    if (x==1450){
        printf("senha correta"); 
    }
    else {
        printf("senha incorreta");
    }
    
    return 0;
}
