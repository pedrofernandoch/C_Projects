#ifndef FUNCOES
#define FUNCOES

void homogenizar(int **, int, int);
void eliminaRuido(int **, int, int);
void frequencia_dos_identificadores_de_numeros(int,int,int **, int **);
int descobre_numero(int, int, int, int, int, int, int, int, int **, int**);

#endif
