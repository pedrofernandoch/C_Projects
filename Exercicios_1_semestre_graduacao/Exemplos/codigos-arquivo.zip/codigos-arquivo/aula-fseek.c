#include <stdio.h>
#include <stdlib.h>


int main(){
	FILE *arq = fopen("fseek.txt", "w");
	if (arq == NULL){
		exit(0);
	}
	fprintf(arq, "%s", "aula de struct");
	fclose(arq);
	return 0;
}
