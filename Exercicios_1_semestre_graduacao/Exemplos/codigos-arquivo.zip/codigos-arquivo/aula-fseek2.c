#include <stdio.h>
#include <stdlib.h>


int main(){
	FILE *arq = fopen("fseek.txt", "r+");
	if (arq == NULL){
		exit(0);
	}
	fseek(arq, 8, SEEK_SET);
	fprintf(arq, "%s", "arquivo");
	fclose(arq);
	return 0;
}
