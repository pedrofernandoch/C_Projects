#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct aluno{
	char nome[40];
	int idade;
	char sexo;
	int matricula;
};

int main(){
	FILE *arq = fopen("conteudo-bin-aluno.bin", "wb");
	if (arq == NULL){
		exit(0);
	}
	typedef struct aluno tAluno;
	tAluno aluno1;
	strcpy(aluno1.nome, "jesimar da silva arantes");
	aluno1.idade = 28;
	aluno1.sexo = 'm';
	aluno1.matricula = 12345;
	
	tAluno aluno2;
	strcpy(aluno2.nome, "marcio da silva arantes");
	aluno2.idade = 30;
	aluno2.sexo = 'm';
	aluno2.matricula = 45522;
	
	tAluno aluno3;
	strcpy(aluno3.nome, "suzana oliveira");
	aluno3.idade = 23;
	aluno3.sexo = 'f';
	aluno3.matricula = 63452;
	
	fwrite(&aluno1, sizeof(tAluno), 1, arq);
	fwrite(&aluno2, sizeof(tAluno), 1, arq);
	fwrite(&aluno3, sizeof(tAluno), 1, arq);
	fclose(arq);
	return 0;
}
