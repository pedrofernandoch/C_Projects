#include <stdio.h>
#include <stdlib.h>

struct aluno{
	char nome[20];
	int idade;
	char sexo;
};

int main(){
	FILE *arq = fopen("arq-texto.txt", "r");
	if (arq == NULL){
		exit(0);
	}
	
	do{
		struct aluno aluno1;
		fscanf(arq, "%d %c %[a-z A-Z]s\n", &aluno1.idade, &aluno1.sexo, aluno1.nome);
		printf("%s\t%d\t%c\n", aluno1.nome, aluno1.idade, aluno1.sexo);
	}while(!feof(arq));
	
	fclose(arq);
	return 0;
}
